
public class Main {
	public static void main(String[] args) {
		FileIn fin = new FileIn("DAYSO.DAT");
		fin.lietKe();
	}
}
