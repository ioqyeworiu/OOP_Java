import java.io.IOException;

public class Main {
	public static void main(String[] args) throws ClassNotFoundException, IOException {
		FileIn fin = new FileIn("DATA.in");
		fin.lietKeNhiPhan();
	}
}
