import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws FileNotFoundException {
		File file = new File("LUYENTAP.in");
		Scanner sc = new Scanner(file);
		ArrayList<SinhVien> arr = new ArrayList<SinhVien>();
		int n = sc.nextInt();
		while(n--!=0) {
			String ten = sc.nextLine();
			int baiDung = sc.nextInt();
			int submit = sc.nextInt();
			SinhVien sv = new SinhVien(ten, baiDung, submit);
			arr.add(sv);
 		}
		DanhSachSinhVien ds = new DanhSachSinhVien(arr);
		ds.sapXep();
		System.out.println(ds.toString());
	}
}
